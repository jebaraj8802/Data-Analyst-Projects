
Project Title: Amazon Prime Video Content Analysis

Overview: This project aims to analyze the vast content library of Amazon Prime Video using data visualization techniques. 
	By creating an interactive Tableau dashboard, we explore trends, genres, and other insights related to movies and TV shows available on the platform.

Key Features:
Radial Bar Chart:
    - Visualizes genre popularity, allowing users to compare different genres.
    - Each segment represents a genre, with bar length indicating popularity.
Donut Chart:
    - Compares the distribution of movies and TV shows.
    - Provides an overview of content types.
Area Chart:
    - Tracks content production over time.
    - Reveals trends in release years.
Interactive Map:
    - Displays filming locations globally.
    - Adds a geographical context to content analysis.
Dynamic Text Sheets:
    - Detailed information about specific titles.
    - Includes cast, descriptions, and more.

Insights
- Discover top-rated shows and explore genre preferences.
- Understand content distribution across different types.
- Observe how content has evolved over the years.

Impact
- This project empowers viewers, content creators, and decision-makers by providing actionable insights into Amazon Prime Video's content landscape.

